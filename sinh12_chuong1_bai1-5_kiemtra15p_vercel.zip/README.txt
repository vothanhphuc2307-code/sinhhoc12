SINH HỌC 12 — KIỂM TRA 15 PHÚT
Chương I: Di truyền phân tử | Kết nối tri thức | Bài 1–5

NỘI DUNG ÔN TẬP
- Bài 1: DNA và cơ chế tái bản DNA (thành phần nucleotide, nguyên tắc bán bảo tồn).
- Bài 2: Gene, truyền đạt thông tin di truyền và hệ gene (cấu trúc gene, vai trò tRNA trong dịch mã).
- Bài 3: Điều hòa biểu hiện gene (operon lac, gene lacI, vai trò lactose).
- Bài 4: Đột biến gene (khái niệm, thêm nucleotide và dịch khung đọc).
- Bài 5: Công nghệ gene (DNA ligase, plasmid/vector).

TÍNH NĂNG
- 10 câu trắc nghiệm, 4 lựa chọn/câu, 15 phút.
- Thanh tiến độ, điều hướng câu, chấm điểm thang 10.
- Tự nộp khi hết giờ; hiện đáp án đúng và giải thích sau khi nộp.
- Responsive cho máy tính và điện thoại; animation nhẹ, có hỗ trợ cài đặt giảm chuyển động.
- Website tĩnh, không cần cài thư viện hoặc backend.

ĐƯA LÊN VERCEL
1. Giải nén ZIP.
2. Đặt index.html ở thư mục gốc của repository GitHub.
3. Import repository ở https://vercel.com/new.
4. Framework Preset: Other; không cần Build Command; Deploy.

LƯU Ý
Đây là đề luyện tập tự biên soạn dựa trên các kiến thức trọng tâm của Bài 1–5, không phải đề chính thức của giáo viên và không thể bảo đảm trùng với đề kiểm tra ngày mai. Website tĩnh chấm điểm ở trình duyệt, phù hợp tự ôn tập, không dùng cho kỳ thi cần giữ bí mật đáp án.
